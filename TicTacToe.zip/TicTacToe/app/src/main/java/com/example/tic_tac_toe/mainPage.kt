package com.example.tic_tac_toe

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.tic_tac_toe.databinding.FragmentMainPageBinding

private var _binding: FragmentMainPageBinding? = null
private val binding get() = _binding!!
/**
 * A simple [Fragment] subclass.
 * Use the [mainPage.newInstance] factory method to
 * create an instance of this fragment.
 */
class mainPage : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMainPageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            easyMode.setOnClickListener{ toNextPage("Easy Mode")}
            hardMode.setOnClickListener{ toNextPage("Hard Mode") }
            twoPlayerMode.setOnClickListener{ toNextPage("Two Player Mode") }

        }

    }

    private fun toNextPage(buttonMode: String){
        val action = mainPageDirections.actionMainPageToUserSelection(gameMode = buttonMode)
        findNavController().navigate(action)
    }

}